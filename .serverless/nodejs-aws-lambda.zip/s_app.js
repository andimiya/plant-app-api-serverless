
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'andimiya',
  applicationName: 'plant-app-api',
  appUid: 'g6DpGBQR4H3dstNPKG',
  orgUid: 'tQ2LMN1Kmm6n6f9cp8',
  deploymentUid: 'bc67a76d-c948-487e-87ce-ccaa7cd7f456',
  serviceName: 'nodejs-aws-lambda',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'prod',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'nodejs-aws-lambda-prod-app', timeout: 6 };

try {
  const userHandler = require('./dist/app.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}